document.addEventListener("DOMContentLoaded", () => {
  const btn = document.getElementById("menuBtn");
  const mobile = document.getElementById("mobileMenu");
  if (btn && mobile) {
    btn.addEventListener("click", () => {
      mobile.classList.toggle("hidden");
    });
  }
});